var switchEle = document.getElementById('switch');
var refreshEle = document.getElementById('refresh');

var backgroundPage = chrome.extension.getBackgroundPage();

backgroundPage.switchState ? switchEle.classList.add('on') : switchEle.classList.remove('on')


switchEle.addEventListener('click', switchEleClickHandler);
refreshEle.addEventListener('click', refreshEleClickHandler);

function switchEleClickHandler() {
	this.classList.toggle('on');
	var thisState = this.classList.contains('on');

	backgroundPage.setBrowserActionIcon(thisState);

	chrome.storage.sync.set({
		switchState: thisState
	}, function() {

		backgroundPage.switchState = thisState;

		setTimeout(function() {
			refreshEle.style.display = 'block';
			setTimeout(function() {
				refreshEleClickHandler();
			}, 500)
		}, 500)
	})
}

function refreshEleClickHandler() {
	chrome.tabs.reload(backgroundPage.currTabId);
	window.close();
}
