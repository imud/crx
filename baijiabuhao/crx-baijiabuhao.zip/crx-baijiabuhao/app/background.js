//msgType:
//0:background ===dom change==> content
//1:content ===original url==> background
//2:background ===baijiahao url==> content

var currTabId;
var tabBadges = {};
var switchState = true;

var baijiahaoRE = /baijiahao/;
var baidusearchRE = /baidu\.com\/s/;
var defaultIcon = 'icon.png';
var activeIcon = 'icon_active.png';
var filterUrl = [
	"*://*.baidu.com/s*ie=utf-8*mod=2*",//搜索框直接输入
	"*://*.baidu.com/s*mod=2*ie=utf-8*",//搜索框直接输入
	"*://*.baidu.com/s*ie=utf-8*wd=*",//点击分页或刷新
	"*://*.baidu.com/s*wd=*ie=utf-8*",//点击分页或刷新
	"*://*.baidu.com/s*tn=news*wd=*",//资讯页
	"*://*.baidu.com/s*tn=news*word=*",//资讯页
	"*://*.baidu.com/s*cl=3*wd=*",//从“音乐”页点击“网页”
	"*://*.baidu.com/s?rsv_xinwen=1&wd=*"//资讯页，点击“去网页搜索”
]

chrome.browserAction.setBadgeBackgroundColor({
	color: [51, 133, 255, 255]
});
chrome.tabs.onActivated.addListener(tabsActivatedHandler);
chrome.webRequest.onCompleted.addListener(webRequestCompletedHandler, {
	urls: filterUrl
}, []);
chrome.runtime.onMessage.addListener(runtimeMessageHandler);

function tabsActivatedHandler(activeInfo) {
	currTabId = activeInfo.tabId;
	tabBadges[currTabId] = tabBadges[currTabId] || 0;
	setBrowserActionBadgeText(currTabId);
	chrome.tabs.get(currTabId, function(tab) {
		setBrowserActionUsability(tab.id, tab.url);
	})
	
	chrome.storage.sync.get({
		switchState: true
	}, function(items) {
		switchState = items.switchState;
	})
}

function webRequestCompletedHandler(details) {
	if (details.type == 'xmlhttprequest' &&
		/mod=1/.test(details.url) &&
		/wd=/.test(details.url)) {
		return;
	}

	tabBadges[details.tabId] = 0;
	setBrowserActionBadgeText(details.tabId);
	setBrowserActionIcon(switchState);
	
	if(switchState){
		console.log('=============send')
		sendMsgToContentScript({
			msgType: 0,
			tabId: details.tabId
		})
	}
}

function runtimeMessageHandler(request, sender, sendResponse) {
	if(request.msgType==1){//msg from content_script
		request.data.forEach(function(href, index) {
			getRealUrl(request.tabId, index, href);
		})
	}
}

function setBrowserActionUsability(tabId, tabUrl) {
	var bool = true;
	if (baidusearchRE.test(tabUrl)) {
		chrome.browserAction.enable(tabId);
	} else {
		chrome.browserAction.disable(tabId);
		bool = false;
	}
	setBrowserActionIcon(bool);
	return bool;
}


function setBrowserActionIcon(bool) {
	chrome.browserAction.setIcon({
		path: switchState && bool ? activeIcon : defaultIcon
	})
}

function setBrowserActionBadgeText(tabId) {
	if (tabId == currTabId) {
		chrome.browserAction.setBadgeText({
			text: String(tabBadges[tabId] || '')
		})
	}
}

function getRealUrl(tabId, index, href) {
	var xhr = new XMLHttpRequest();
	xhr.open('HEAD', href, true);
	xhr.addEventListener('readystatechange', function() {
		if (this.readyState == 4) {
			var url = this.responseURL;
			if (baijiahaoRE.test(url)) {
				tabBadges[tabId] += 1;
				setBrowserActionBadgeText(tabId);
				sendMsgToContentScript({
					msgType: 2,
					tabId: tabId,
					index: index,
					url: url
				})
			}
		}
	})
	xhr.send();
}

function sendMsgToContentScript(msg, callback) {
	if (msg.url) {
		console.log('baijiahao-url:' + msg.url);
	}
	chrome.tabs.sendMessage(msg.tabId, msg)
}
