// document.documentElement.style.visibility = 'hidden';
var resultLinkSelector = '#content_left .result>h3>a[data-click],#content_left .result-op>.c-offset>div>a';
var baijiahaoItemStyle = 'pointer-events: none;-webkit-filter: grayscale(100%);opacity:.25;';

var resultLinkList = [];

chrome.runtime.onMessage.addListener(runtimeMessageHandler);

function runtimeMessageHandler(request, sender, sendResponse) {
	var tabId = request.tabId;
	if (request.msgType == 0) { //msg from background / dom change
		domready(function() {
			setTimeout(function() {
				getResultHref(tabId)
			}, 100)
		})
	} else if (request.msgType == 2) { //msg from background / baijiahao link node 
		var item = resultLinkList[request.index];
		if (item) {
			//baijiahao item element
			var parentTest = item.parentNode.parentNode;
			var ele = parentTest.classList.contains('result') ? parentTest : item.parentNode
			//set style
			ele.style.cssText = baijiahaoItemStyle;
			//remove
			// ele.parentNode.removeChild(ele);
		}
	}
}

function getResultHref(tabId) {
	resultLinkList = document.querySelectorAll(resultLinkSelector);
	if (resultLinkList.length) {
		var hrefArr = [];
		for (var i = 0; i < resultLinkList.length; i++) {
			hrefArr[i] = resultLinkList[i].href;
		}
		//send msg to background
		chrome.runtime.sendMessage({
			msgType: 1,
			tabId: tabId,
			data: hrefArr
		})

	}
}

function domready(callback) {
	if (/complete|interacive|loaded/.test(document.readyState) && document.body) {
		callback.call();
	} else {
		document.addEventListener('DOMContentLoaded', function() {
			callback.call();
		}, false);
	}
}
