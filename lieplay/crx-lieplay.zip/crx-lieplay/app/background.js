var SIGN = 'background';
var EXT_APIS_URL = 'https://imud.github.io/crx/lieplay/api.json';
var EXT_ICONS = {
	'inactive': 'icon/icon_inactive.png',
	'auto': 'icon/icon.png',
	'active': 'icon/icon_active.png'
};

var _extData_ = {
	mode: 'auto',
	currAPI: '',
	addedAPIs: [],
	customAPIs: [],
	matches: [
		"*://v.youku.com/v_*",
		"*://*.iqiyi.com/v_*",
		"*://*.iqiyi.com/w_*",
		"*://*.iqiyi.com/a_*",
		"*://*.iqiyi.com/dianying/*",
		"*://*.le.com/ptv/vplay/*",
		"*v.qq.com/x/cover/*",
		"*v.qq.com/x/page/*",
		"*://*.tudou.com/listplay/*",
		"*://*.tudou.com/albumplay/*",
		"*://*.tudou.com/programs/view/*",
		"*://*.mgtv.com/b/*",
		"*://film.sohu.com/album/*",
		"*://tv.sohu.com/*",
		"*://*.acfun.cn/v/*",
		"*://*.bilibili.com/video/*",
		"*://*.bilibili.com/anime/*",
		"*://*.bilibili.com/bangumi/play/*",
		"*://vip.pptv.com/show/*",
		"*://v.pptv.com/show/*",
		"*://v.yinyuetai.com/video/*",
		"*://v.yinyuetai.com/playlist/*"
	]
};


//窗口创建时初始化插件
chrome.windows.onCreated.addListener(extensionInit);

//content点击播放时
chrome.runtime.onMessage.addListener(function(req, sender, sendRes) {
	if (req.sign == 'content' && req.url) {
		gotoPlayPage(req.url)
	}
})

//tab激活时更新状态
chrome.tabs.onActivated.addListener(function(info) {
	sendMsg(_extData_);
})
// chrome.tabs.onRemoved.addListener(function (id) {})

//创建右键菜单
chrome.contextMenus.create({
	title: "LiePlay解析本页视频",
	onclick: function() {
		getCurrentTab(function(tab) {
			gotoPlayPage(tab.url)
		})
	}
})

extensionInit();


function extensionInit() {
	//从本地获取
	chrome.storage.sync.get('EXT_LIEPLAY', function(data) {
		if (data && data.ext) {
			var storageData = data.ext;
			for (var i in _extData_) {
				var item = storageData[i];
				if (item && item.length) {
					_extData_[i] = item;
				}
			}
		}

		//从远程更新
		loadRemoteConfig(function(res) {
			if (res) {
				_extData_.matches = res.matches;
				_extData_.customAPIs = res.apilist;
				_extData_.currAPI = _extData_.currAPI || res.apilist[0];
			}

			if (_extData_.customAPIs.indexOf(_extData_.currAPI) == -1 &&
				_extData_.addedAPIs.indexOf(_extData_.currAPI) == -1) {
				_extData_.currAPI = '';
			}

			setExtData(SIGN, _extData_);
		})

	})
}


function loadRemoteConfig(callback) {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', EXT_APIS_URL, true);
	xhr.responseType = 'json';
	xhr.addEventListener('readystatechange', function() {
		if (this.readyState == 4) {
			callback(this.response)
		}
	})
	xhr.send();
}

function gotoPlayPage(url) {
	if (!_extData_.currAPI) {

		new Notification("没有可解析的线路，请配置!");
		return;
	}

	chrome.tabs.create({
		url: chrome.extension.getURL('play.html') + '?url=' + url
	})
}

function getCurrentTab(callback) {
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function(tabs) {
		callback(tabs[0])
	})
}


function setExtData(sign, ext) {
	chrome.browserAction.setIcon({
		path: EXT_ICONS[ext.mode]
	})

	chrome.storage.sync.set({
		'EXT_LIEPLAY': ext
	}, function() {
		_extData_ = ext;
		if (sign !== 'play') {
			sendMsg(_extData_)
		}
	})
}


function sendMsg(data) {
	getCurrentTab(function(tab) {
		chrome.tabs.sendMessage(tab.id, {
			sign: SIGN,
			data: data
		})
	})
}
