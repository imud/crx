var SIGN = 'popup';
var bgPage = chrome.extension.getBackgroundPage();
var extData = bgPage._extData_;
var VM = new Vue({
	el: '#popupPage',
	data: {
		ext: extData,
		form: {
			state: false,
			url: ''
		}
	},
	methods: {
		toggleDetail: function(event, api) {
			var box = event.currentTarget.parentNode.parentNode;
			box.classList.toggle('hover');
		},
		apiDel: function(api, index) {
			this.ext.addedAPIs.splice(index, 1);
			if (api == this.ext.currAPI) {
				this.ext.currAPI = this.ext.customAPIs[0] || this.ext.addedAPIs[0];
			}
		},
		formShow: function() {
			this.form.state = true;
		},
		formCancel: function() {
			this.form.state = false;
			this.form.url = '';
		},
		formSave: function() {
			var url = this.form.url.replace(/\s/, '');
			if (url) {
				if (this.ext.addedAPIs.indexOf(url) == -1) {
					this.ext.addedAPIs.push(url);
					this.form.state = false;
					this.form.url = '';
				}
				if (this.ext.customAPIs.length == 0 && this.ext.addedAPIs.length == 1) {
					this.ext.currAPI = url;
				}
			}
		}
	},
	watch: {
		ext: {
			handler: function() {
				bgPage.setExtData(SIGN, JSON.parse(JSON.stringify(this.ext)))
			},
			deep: true
		}
	}
})
