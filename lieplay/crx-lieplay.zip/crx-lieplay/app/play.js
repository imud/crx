var SIGN = 'play';
var url = window.location.search.replace('?url=', '');
var bgPage = chrome.extension.getBackgroundPage();
var extData = bgPage._extData_;
var VM = new Vue({
	el: '#playPage',
	data: {
		ext: extData,
		videoUrl: '',
		dockerActive: false
	},
	methods: {
		toggleDocker: function() {
			this.dockerActive = !this.dockerActive;
		},
		toggleDetail: function(event, api) {
			var box = event.currentTarget.parentNode.parentNode;
			box.classList.toggle('hover');
		}
	},
	watch: {
		'ext.currAPI': function(newVal, oldVal) {
			this.videoUrl = newVal + url;
			bgPage.setExtData(SIGN, JSON.parse(JSON.stringify(this.ext)))
		}
	},
	created() {
		this.videoUrl = this.ext.currAPI + url;
		var vm = this;
		chrome.runtime.onMessage.addListener(function(req, sender, sendRes) {
			if (req.sign == 'background') {
				vm.ext = req.data;
			}
		})
	}
})
