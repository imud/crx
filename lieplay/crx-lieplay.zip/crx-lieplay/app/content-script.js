var SIGN = 'content';
var href = window.location.href;
var docker = null;
var mode = null;
domready(function() {
	chrome.runtime.onMessage.addListener(function(req, sender, sendRes) {
		if (req.sign == 'background' && req.data.mode !== mode) {
			checkMode(req.data)
		}
	})

	chrome.storage.sync.get('EXT_LIEPLAY', function(data) {
		if (data && data.EXT_LIEPLAY) {
			checkMode(data.EXT_LIEPLAY)
		}
	})
})

function checkMode(ext) {
	mode = ext.mode;
	if (mode == 'active' || (mode == 'auto' && ext.matches.some(function(item) {
			var reg = new RegExp(wildcard2regex(item));
			return reg.test(href);
		}))) {

		initDocker();
	} else if (docker && docker.parentNode) {
		docker.parentNode.removeChild(docker);
	} else {

	}
}

function initDocker() {

	if (docker && docker.parentNode) {
		docker.parentNode.removeChild(docker);
	}
	var elTpl = '<div class="___liePlaybox___"><i></i><i></i><i></i><i></i><i></i></div>';
	docker = document.createElement('div');
	docker.id = '___liePlay___';
	docker.innerHTML = elTpl;
	document.body.appendChild(docker);
	docker.onclick = function() {

		if (typeof chrome.app.isInstalled !== 'undefined') {
			chrome.runtime.sendMessage({
				sign: SIGN,
				url: window.location.href
			})
		} else {
			window.location.reload()
		}

	}

}

function domready(callback) {
	if (/complete|interacive|loaded/.test(document.readyState) && document.body) {
		callback.call();
	} else {
		document.addEventListener('DOMContentLoaded', function() {
			callback.call();
		}, false);
	}
}

function wildcard2regex(str) {
	return str.replace('.', '\\.').replace('*', '.*')
}
